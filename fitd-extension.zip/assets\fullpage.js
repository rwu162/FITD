import{r as o,j as e,c as me,R as he}from"./styling.js";/* empty css         *//* empty css     */const ue=({wardrobe:w,onClose:N,onSave:C})=>{const[u,x]=o.useState({tops:null,bottoms:null,shoes:null,outerwear:null,accessories:null}),[c,E]=o.useState({name:"",occasion:"casual",notes:""}),[p,j]=o.useState(null),[m,y]=o.useState(!1),S=a=>w.filter(r=>r.category===a),g=a=>{const{name:r,value:f}=a.target;E(h=>({...h,[r]:f}))},B=a=>{j(a),y(!0)},n=()=>{y(!1),j(null)},A=a=>{x(r=>({...r,[p]:a})),y(!1)},I=a=>{x(r=>({...r,[a]:null}))},M=()=>{if(!u.tops||!u.bottoms){alert("An outfit requires at least a top and bottom!");return}const a={id:Date.now().toString(),name:c.name||"Unnamed Outfit",items:u,occasion:c.occasion,notes:c.notes,createdAt:new Date().toISOString()};C(a)},L=()=>{if(!m||!p)return null;const a=S(p);return e.jsxs("div",{className:"item-selection-panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("h4",{children:["Select ",p]}),e.jsx("button",{className:"close-panel",onClick:n,children:"×"})]}),e.jsx("div",{className:"item-selection-grid",children:a.length===0?e.jsxs("p",{children:["No ",p," items found in your wardrobe."]}):a.map(r=>e.jsxs("div",{className:"selection-item",onClick:()=>A(r),children:[e.jsx("img",{src:r.imageUrl,alt:r.title||p,onError:f=>{f.target.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"%3E%3Crect width="100" height="100" fill="%23f0f0f0"/%3E%3Ctext x="50" y="50" font-family="Arial" font-size="12" text-anchor="middle" dominant-baseline="middle" fill="%23999"%3EImage not available%3C/text%3E%3C/svg%3E'}}),e.jsx("p",{className:"selection-item-title",children:r.title||"Unnamed item"})]},r.addedAt))})]})};return e.jsxs("div",{className:"outfit-creator",children:[e.jsxs("div",{className:"outfit-creator-header",children:[e.jsx("h3",{children:"Create New Outfit"}),e.jsx("button",{className:"icon-button",onClick:N,children:"×"})]}),e.jsxs("div",{className:"outfit-builder",children:[e.jsx("div",{className:"outfit-items",children:["tops","bottoms","shoes","outerwear","accessories"].map(a=>{const r=u[a],f=a==="tops"||a==="bottoms";return e.jsxs("div",{className:"outfit-item-slot",onClick:()=>B(a),children:[e.jsxs("div",{className:"slot-label",children:[a.charAt(0).toUpperCase()+a.slice(1),f&&e.jsx("span",{className:"required",children:"*"})]}),e.jsx("div",{className:`slot-content ${r?"":"empty"}`,children:r?e.jsxs(e.Fragment,{children:[e.jsx("img",{src:r.imageUrl,alt:r.title||a}),e.jsx("button",{className:"remove-item-btn",onClick:h=>{h.stopPropagation(),I(a)},children:"×"})]}):e.jsxs("div",{className:"add-item-placeholder",children:[e.jsx("span",{children:"+"}),e.jsxs("p",{children:["Add ",a]})]})})]},a)})}),e.jsxs("div",{className:"outfit-details",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"outfit-name",children:"Outfit Name"}),e.jsx("input",{type:"text",id:"outfit-name",name:"name",value:c.name,onChange:g,placeholder:"e.g., Summer Casual"})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"outfit-occasion",children:"Occasion"}),e.jsxs("select",{id:"outfit-occasion",name:"occasion",value:c.occasion,onChange:g,children:[e.jsx("option",{value:"casual",children:"Casual"}),e.jsx("option",{value:"formal",children:"Formal"}),e.jsx("option",{value:"work",children:"Work"}),e.jsx("option",{value:"date",children:"Date Night"}),e.jsx("option",{value:"sports",children:"Sports/Active"}),e.jsx("option",{value:"special",children:"Special Occasion"}),e.jsx("option",{value:"other",children:"Other"})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{htmlFor:"outfit-notes",children:"Notes"}),e.jsx("textarea",{id:"outfit-notes",name:"notes",value:c.notes,onChange:g,placeholder:"Any notes or thoughts about this outfit...",rows:"4"})]}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{className:"primary-button",onClick:M,disabled:!u.tops||!u.bottoms,children:"Save Outfit"}),e.jsx("button",{className:"secondary-button",onClick:N,children:"Cancel"})]})]})]}),L()]})};function fe(){const[w,N]=o.useState("wardrobe"),[C,u]=o.useState("all"),[x,c]=o.useState([]),[E,p]=o.useState([]),[j,m]=o.useState([]),[y,S]=o.useState(!0),[g,B]=o.useState(""),[n,A]=o.useState(null),[I,M]=o.useState(!1),[L,a]=o.useState(!1),[r,f]=o.useState("wardrobe-tab-menu"),[h,Y]=o.useState("newest"),[P,F]=o.useState(!1),[d,T]=o.useState(null),[q,W]=o.useState(!1);o.useEffect(()=>{const i=new URLSearchParams(window.location.search).get("tab");i&&(N(i),f(`${i}-tab-menu`),i==="outfit"&&a(!0)),H(),Q()},[]),o.useEffect(()=>{let t=[...x];if(C!=="all"&&(t=t.filter(i=>i.category===C)),g.trim()!==""){const i=g.toLowerCase();t=t.filter(s=>`${s.title||""} ${s.brand||""} ${s.description||""}`.toLowerCase().includes(i))}t=le(t),p(t)},[C,g,x,h]),o.useEffect(()=>{const t=(i,s,l)=>{if(i.action==="wardrobeUpdated")return console.log("Received wardrobe update, refreshing data"),c(i.wardrobe||[]),!0};return chrome.runtime.onMessage.addListener(t),()=>{chrome.runtime.onMessage.removeListener(t)}},[]);const _=()=>{F(!P)},U=t=>{Y(t),F(!1)},H=()=>{S(!0),chrome.runtime&&chrome.runtime.sendMessage?chrome.runtime.sendMessage({action:"getWardrobe"},t=>{t&&t.success?c(t.wardrobe||[]):console.error("Failed to load wardrobe data"),S(!1)}):(console.warn("Chrome runtime not available. Using empty wardrobe for development."),c([]),S(!1))},Q=()=>{chrome.storage&&chrome.storage.local?chrome.storage.local.get(["outfits","savedOutfits"],t=>{t.savedOutfits&&t.savedOutfits.length>0?(m(t.savedOutfits),console.log("Loaded outfits from savedOutfits key:",t.savedOutfits.length)):t.outfits&&t.outfits.length>0?(m(t.outfits),console.log("Loaded outfits from outfits key:",t.outfits.length),chrome.storage.local.set({savedOutfits:t.outfits},()=>{console.log("Migrated outfits to new storage key")})):(console.log("No outfits found in storage"),m([]))}):(console.log("Chrome storage not available, using empty outfits array"),m([]))},b=(t,i)=>{N(t),t==="wardrobe"&&u("all"),f(`${t}-tab-menu`)},O=t=>{u(t),f(`${t}-tab-menu`)},J=t=>{B(t.target.value)},G=t=>{A(t),M(!0)},$=()=>{M(!1),A(null)},K=t=>{if(window.confirm("Are you sure you want to remove this item from your wardrobe?")){const i=x.filter(s=>s.addedAt!==t);chrome.runtime&&chrome.runtime.sendMessage?chrome.runtime.sendMessage({action:"updateWardrobe",wardrobe:i},s=>{s&&s.success&&(c(i),$())}):(c(i),$())}},X=()=>{a(!0)},Z=()=>{a(!1)},ee=t=>{T(t),W(!0)},R=()=>{W(!1),T(null)},te=()=>e.jsxs("div",{className:"filter-controls",children:[e.jsx("div",{className:"filter-left",children:e.jsxs("div",{className:`sort-container ${P?"active":""}`,children:[e.jsxs("div",{className:"sort-header",onClick:_,children:[e.jsx("span",{className:"sort-text",children:"Sort By"}),e.jsx("span",{className:"sort-icon",children:P?"–":"+"})]}),P&&e.jsxs("div",{className:"sort-options",children:[e.jsx("div",{className:`sort-option ${h==="newest"?"active":""}`,onClick:()=>U("newest"),children:"Newest"}),e.jsx("div",{className:`sort-option ${h==="oldest"?"active":""}`,onClick:()=>U("oldest"),children:"Oldest"}),e.jsx("div",{className:`sort-option ${h==="price-low-high"?"active":""}`,onClick:()=>U("price-low-high"),children:"Price: Low to High"}),e.jsx("div",{className:`sort-option ${h==="price-high-low"?"active":""}`,onClick:()=>U("price-high-low"),children:"Price: High to Low"})]})]})}),e.jsx("div",{className:"filter-right",children:e.jsx("div",{className:"search-container",children:e.jsx("input",{type:"text",id:"search-wardrobe",placeholder:"Search items...",value:g,onChange:J})})})]}),se=t=>{const i={id:t.id||"outfit_"+Date.now(),name:t.name||"My Outfit",items:t.items,reasoning:t.reasoning||"",createdAt:t.createdAt||new Date().toISOString()};if(chrome.storage&&chrome.storage.local)chrome.storage.local.get("savedOutfits",s=>{const l=s.savedOutfits||[],v=[i,...l];chrome.storage.local.set({savedOutfits:v},()=>{m(v),a(!1),chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"/logo.png",title:"Outfit Saved",message:`"${i.name}" has been added to your collection!`})})});else{const s=[i,...j];m(s),a(!1)}},z=t=>{if(window.confirm("Are you sure you want to delete this outfit?")){const i=j.filter(s=>s.id!==t);chrome.storage&&chrome.storage.local?chrome.storage.local.set({savedOutfits:i},()=>{m(i),d&&d.id===t&&R()}):(m(i),d&&d.id===t&&R())}},ie=t=>{if(!t)return"$0.00";const s=t.toString().match(/(\d+(\.\d+)?)/);return`$${(s?parseFloat(s[0]):0).toFixed(2)}`},ae=()=>y?e.jsx("div",{className:"loading",children:"Loading your wardrobe..."}):x.length===0?e.jsx("div",{className:"empty-state",children:e.jsx("p",{children:"Your wardrobe is empty. Add items by right-clicking on clothing images while browsing."})}):E.length===0?e.jsx("div",{className:"empty-state",children:e.jsx("p",{children:"No items found in this category. Try adding some or changing your filter."})}):e.jsx("div",{className:"items-grid-container",children:E.map(t=>e.jsxs("div",{className:"item-card","data-category":t.category,onClick:()=>G(t),children:[e.jsx("div",{className:"item-image",children:e.jsx("img",{src:t.imageUrl,alt:t.title||"Product image",onError:i=>{i.target.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"%3E%3Crect width="100" height="100" fill="%23f0f0f0"/%3E%3Ctext x="50" y="50" font-family="Arial" font-size="12" text-anchor="middle" dominant-baseline="middle" fill="%23999"%3EImage not available%3C/text%3E%3C/svg%3E'}})}),e.jsxs("div",{className:"item-details",children:[e.jsx("p",{className:"item-brand",children:t.brand||"BRAND"}),e.jsx("h3",{children:t.title||"Unknown Product"}),e.jsx("p",{className:"item-price",children:ie(t.price)})]})]},t.addedAt))}),re=()=>j.length===0?e.jsxs("div",{className:"empty-state",children:[e.jsx("p",{children:"You haven't created any outfits yet. Start by going to STYLER."}),e.jsx("button",{className:"primary-button create-outfit-button",onClick:X,children:"Create New Outfit"})]}):e.jsx("div",{className:"outfits-grid",children:j.map(t=>{const i=Object.entries(t.items||{}).filter(([s,l])=>l!==null).map(([s,l])=>e.jsx("div",{className:"outfit-item-thumbnail","data-category":s,children:e.jsx("img",{src:l.imageUrl,alt:l.title||s,onError:v=>{v.target.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"%3E%3Crect width="100" height="100" fill="%23f0f0f0"/%3E%3Ctext x="50" y="50" font-family="Arial" font-size="12" text-anchor="middle" dominant-baseline="middle" fill="%23999"%3EImage not available%3C/text%3E%3C/svg%3E'}})},s));return e.jsxs("div",{className:"outfit-card",onClick:()=>ee(t),children:[e.jsx("div",{className:"outfit-name",children:e.jsx("h3",{children:t.name})}),e.jsx("div",{className:"outfit-items-grid",children:i}),e.jsxs("div",{className:"outfit-footer",children:[e.jsx("span",{className:"outfit-created-date",children:new Date(t.createdAt).toLocaleDateString()}),e.jsx("button",{className:"icon-button delete-outfit",onClick:s=>{s.stopPropagation(),z(t.id)},children:e.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:e.jsx("path",{d:"M3 6h18M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"})})})]})]},t.id)})}),oe=()=>e.jsxs("div",{className:"add-container",children:[e.jsx("h2",{children:"Add to Your Wardrobe"}),e.jsx("p",{children:"To add items to your wardrobe, simply use the right-click method:"}),e.jsxs("div",{className:"add-method-card",children:[e.jsx("h3",{children:"Right-Click on Images"}),e.jsx("p",{children:'When browsing shopping websites, right-click on any clothing image and select "Add to Virtual Closet" from the context menu.'})]})]}),le=t=>{if(!t||t.length===0)return[];const i=[...t];switch(h){case"price-low-high":return i.sort((s,l)=>{var k,D;const v=parseFloat(((k=s.price)==null?void 0:k.replace(/[^\d.-]/g,""))||0),V=parseFloat(((D=l.price)==null?void 0:D.replace(/[^\d.-]/g,""))||0);return v-V});case"price-high-low":return i.sort((s,l)=>{var k,D;const v=parseFloat(((k=s.price)==null?void 0:k.replace(/[^\d.-]/g,""))||0);return parseFloat(((D=l.price)==null?void 0:D.replace(/[^\d.-]/g,""))||0)-v});case"oldest":return i.sort((s,l)=>new Date(s.addedAt||0)-new Date(l.addedAt||0));case"newest":return i.sort((s,l)=>new Date(l.addedAt||0)-new Date(s.addedAt||0));case"favorites":return i.sort((s,l)=>(l.favorite?1:0)-(s.favorite?1:0));default:return i}},ne=()=>{if(!I||!n)return null;const t=n.addedAt?new Date(n.addedAt).toLocaleDateString():"Unknown";return e.jsx("div",{className:`modal ${I?"":"hidden"}`,children:e.jsxs("div",{className:"modal-content",children:[e.jsxs("div",{className:"modal-header",children:[e.jsx("h3",{children:n.title||"Item Details"}),e.jsx("button",{className:"close-button",onClick:$,children:"×"})]}),e.jsxs("div",{className:"modal-body",children:[e.jsx("div",{className:"item-image-container",children:e.jsx("img",{src:n.imageUrl,alt:"Item Image",onError:i=>{i.target.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"%3E%3Crect width="100" height="100" fill="%23f0f0f0"/%3E%3Ctext x="50" y="50" font-family="Arial" font-size="12" text-anchor="middle" dominant-baseline="middle" fill="%23999"%3EImage not available%3C/text%3E%3C/svg%3E'}})}),e.jsxs("div",{className:"item-details",children:[e.jsxs("div",{className:"detail-row",children:[e.jsx("span",{className:"detail-label",children:"Brand:"}),e.jsx("span",{className:"detail-value",children:n.brand||"-"})]}),e.jsxs("div",{className:"detail-row",children:[e.jsx("span",{className:"detail-label",children:"Price:"}),e.jsx("span",{className:"detail-value",children:n.price||"-"})]}),e.jsxs("div",{className:"detail-row",children:[e.jsx("span",{className:"detail-label",children:"Category:"}),e.jsx("span",{className:"detail-value",children:n.category||"Uncategorized"})]}),e.jsxs("div",{className:"detail-row",children:[e.jsx("span",{className:"detail-label",children:"Added:"}),e.jsx("span",{className:"detail-value",children:t})]}),e.jsxs("div",{className:"detail-row full-width",children:[e.jsx("span",{className:"detail-label",children:"Description:"}),e.jsx("p",{className:"detail-value",children:n.description||"No description available."})]}),n.detailedDescription&&e.jsxs("div",{className:"detail-row full-width",children:[e.jsx("span",{className:"detail-label",children:"Detailed Description:"}),e.jsx("p",{className:"detail-value",children:n.detailedDescription})]})]})]}),e.jsxs("div",{className:"modal-footer",children:[n.url&&e.jsx("a",{href:n.url,target:"_blank",rel:"noopener noreferrer",className:"secondary-button",children:"View Original"}),e.jsx("button",{className:"danger-button",onClick:()=>K(n.addedAt),children:"Remove from Wardrobe"})]})]})})},ce=()=>{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage?chrome.runtime.sendMessage({action:"openOutfitCreator",navigateTo:"category-selector"},t=>{chrome.runtime.lastError&&console.error("Error navigating to category selector:",chrome.runtime.lastError)}):window.location.href="/category-selector.html"},de=()=>{if(!q||!d)return null;const t=d.createdAt?new Date(d.createdAt).toLocaleDateString():"Unknown";return e.jsx("div",{className:"modal outfit-details-modal",children:e.jsxs("div",{className:"modal-content outfit-details-content",children:[e.jsxs("div",{className:"modal-header",children:[e.jsx("h3",{children:d.name||"Outfit Details"}),e.jsx("button",{className:"close-button",onClick:R,children:"×"})]}),d.reasoning&&e.jsx("div",{className:"outfit-description",children:e.jsx("p",{children:d.reasoning})}),e.jsx("div",{className:"outfit-items-detail",children:Object.entries(d.items||{}).filter(([i,s])=>s!==null).map(([i,s])=>e.jsxs("div",{className:"outfit-item-detail",children:[e.jsx("div",{className:"outfit-item-image",children:e.jsx("img",{src:s.imageUrl,alt:s.title||i,onError:l=>{l.target.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"%3E%3Crect width="100" height="100" fill="%23f0f0f0"/%3E%3Ctext x="50" y="50" font-family="Arial" font-size="12" text-anchor="middle" dominant-baseline="middle" fill="%23999"%3EImage not available%3C/text%3E%3C/svg%3E'}})}),e.jsxs("div",{className:"outfit-item-info",children:[e.jsx("h4",{children:i.charAt(0).toUpperCase()+i.slice(1)}),e.jsx("p",{className:"item-title",children:s.title||"Unknown Item"}),s.brand&&e.jsxs("p",{className:"item-brand",children:["Brand: ",s.brand]}),s.price&&e.jsxs("p",{className:"item-price",children:["Price: ",s.price]}),s.color&&e.jsxs("p",{className:"item-color",children:["Color: ",s.color]}),s.material&&e.jsxs("p",{className:"item-material",children:["Material: ",s.material]}),s.description&&e.jsx("div",{className:"item-description",children:e.jsx("p",{children:s.description})}),s.url&&e.jsx("a",{href:s.url,target:"_blank",rel:"noopener noreferrer",className:"item-link secondary-button",children:"View Original"})]})]},i))}),e.jsxs("div",{className:"modal-footer",children:[e.jsxs("span",{className:"outfit-date",children:["Created: ",t]}),e.jsx("button",{className:"danger-button",onClick:()=>z(d.id),children:"Delete Outfit"})]})]})})};return e.jsxs("div",{id:"app",className:"fullscreen-app",children:[e.jsx("div",{className:"top-right-styler",children:e.jsx("button",{className:"styler-button",onClick:ce,children:"STYLER"})}),e.jsxs("nav",{className:"navbar",children:[e.jsxs("div",{className:"top-bar",children:[e.jsx("div",{className:"logo",children:e.jsx("img",{src:"logo.png",alt:"Virtual Closet Logo",height:"50px"})}),e.jsx("h1",{className:"title",children:"WARDROBE"})]}),e.jsx("div",{className:"nav-container",children:e.jsxs("ul",{className:"nav-links",children:[e.jsx("li",{id:"wardrobe-tab-menu",className:r==="wardrobe-tab-menu"?"active":"",children:e.jsx("a",{href:"#wardrobe",onClick:t=>{t.preventDefault(),b("wardrobe")},children:"View All"})}),e.jsx("li",{id:"tops-tab-menu",className:r==="tops-tab-menu"?"active":"",children:e.jsx("a",{href:"#tops",onClick:t=>{t.preventDefault(),b("wardrobe"),O("tops")},children:"Tops"})}),e.jsx("li",{id:"bottoms-tab-menu",className:r==="bottoms-tab-menu"?"active":"",children:e.jsx("a",{href:"#bottoms",onClick:t=>{t.preventDefault(),b("wardrobe"),O("bottoms")},children:"Bottoms"})}),e.jsx("li",{id:"dresses-tab-menu",className:r==="dresses-tab-menu"?"active":"",children:e.jsx("a",{href:"#dresses",onClick:t=>{t.preventDefault(),b("wardrobe"),O("dresses")},children:"Dresses/Jumpsuits"})}),e.jsx("li",{id:"shoes-tab-menu",className:r==="shoes-tab-menu"?"active":"",children:e.jsx("a",{href:"#shoes",onClick:t=>{t.preventDefault(),b("wardrobe"),O("shoes")},children:"Shoes"})}),e.jsx("li",{id:"accessories-tab-menu",className:r==="accessories-tab-menu"?"active":"",children:e.jsx("a",{href:"#accessories",onClick:t=>{t.preventDefault(),b("wardrobe"),O("accessories")},children:"Accessories"})}),e.jsx("li",{id:"outfit-tab-menu",className:r==="outfit-tab-menu"?"active":"",children:e.jsx("a",{href:"#outfits",onClick:t=>{t.preventDefault(),b("outfit")},children:"Outfits"})})]})})]}),e.jsxs("main",{children:[e.jsxs("section",{id:"wardrobe-view",className:w==="wardrobe"?"":"hidden",children:[te(),ae()]}),e.jsxs("section",{id:"outfits-view",className:w==="outfit"?"":"hidden",children:[e.jsx("div",{className:"outfits-header",children:e.jsx("h2",{children:"Your Outfits"})}),e.jsx("div",{id:"outfits-container",children:re()}),L&&e.jsx(ue,{wardrobe:x,onClose:Z,onSave:se})]}),e.jsx("section",{id:"add-view",className:w==="add"?"":"hidden",children:oe()})]}),ne(),de(),e.jsx("style",{jsx:!0,children:`
        /* Outfit Details Modal Styling */
        .outfit-details-modal {
          z-index: 1001; /* Higher than regular modal */
        }
        
        .outfit-details-content {
          max-width: 800px;
          width: 90%;
          max-height: 85vh;
        }
        
        .outfit-description {
          margin-bottom: 20px;
          font-style: italic;
          color: #666;
          padding: 10px;
          background-color: #f9f9f9;
          border-radius: 6px;
        }
        
        .outfit-items-detail {
          display: flex;
          flex-direction: column;
          gap: 20px;
          margin-bottom: 20px;
        }
        
        .outfit-item-detail {
          display: flex;
          border: 1px solid #eee;
          border-radius: 8px;
          overflow: hidden;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .outfit-item-detail:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .outfit-item-image {
          width: 200px;
          height: 200px;
          overflow: hidden;
          background-color: #f7f7f7;
        }
        
        .outfit-item-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        .outfit-item-info {
          flex: 1;
          padding: 16px;
        }
        
        .outfit-item-info h4 {
          margin: 0 0 8px 0;
          font-size: 14px;
          text-transform: uppercase;
          color: #888;
        }
        
        .item-title {
          font-size: 16px;
          font-weight: 600;
          margin: 0 0 12px 0;
        }
        
        .item-brand, .item-price, .item-color, .item-material {
          font-size: 14px;
          margin: 4px 0;
          color: #555;
        }
        
        .item-description {
          font-size: 14px;
          margin-top: 10px;
          color: #666;
        }
        
        .item-link {
          display: inline-block;
          margin-top: 12px;
          text-decoration: none;
        }
        
        .outfit-date {
          color: #888;
          font-size: 14px;
        }
        
        /* Make outfit cards clickable */
        .outfit-card {
          cursor: pointer;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .outfit-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }
        
        .create-outfit-button {
          margin-left: auto;
        }
        
        .outfits-header {
          display: flex;
          align-items: center;
          margin-bottom: 20px;
        }
        
        /* Responsive design for mobile */
        @media (max-width: 768px) {
          .outfit-item-detail {
            flex-direction: column;
          }
          
          .outfit-item-image {
            width: 100%;
            height: 180px;
          }
          
          .outfit-details-content {
            width: 95%;
            padding: 15px;
          }
        }
      `})]})}const xe=me.createRoot(document.getElementById("app"));xe.render(e.jsx(he.StrictMode,{children:e.jsx(fe,{})}));
